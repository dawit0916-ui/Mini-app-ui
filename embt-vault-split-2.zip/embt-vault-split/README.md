# EMBT Vault - Split Files Structure

✅ **All files organized and ready to use**

## 📦 What's Included

```
embt-vault-split/
├── index.html              ← Main entry point
├── README.md               ← This file
├── SETUP_GUIDE.txt         ← Complete setup instructions
│
├── css/                    ← 7 CSS files
│   ├── global.css
│   ├── layout.css
│   ├── wheel.css
│   ├── wallet.css
│   ├── modals.css
│   ├── admin.css
│   └── console.css
│
├── js/                     ← 13 JavaScript files
│   ├── config.js           ✅ (configured)
│   ├── api.js              ✅ (ready)
│   ├── loader.js           ✅ (configured)
│   ├── modals.js           ✅ (ready)
│   ├── notifications.js    (stub - add your code)
│   ├── wheel.js            (stub - add your code)
│   ├── tasks.js            (stub - add your code)
│   ├── wallet.js           (stub - add your code)
│   ├── referrals.js        (stub - add your code)
│   ├── profile.js          (stub - add your code)
│   ├── admin.js            (stub - add your code)
│   ├── console.js          (stub - add your code)
│   └── app.js              (stub - add your code)
│
└── components/             (Create as needed)
    ├── tabs/
    ├── modals/
    └── popups/
```

## ⚡ Quick Start

### Option 1: Use as-is (Fast Start)
1. Extract this zip
2. Copy your existing `index.html` code into the JS files (see SETUP_GUIDE.txt)
3. Upload to server
4. Done!

### Option 2: Already have the code?
1. Extract this zip
2. Copy your existing CSS into `css/` files
3. Copy your existing JS functions into `js/` files
4. Copy HTML components into `components/` folder
5. Upload to server

## 🔧 Configuration

Update `js/config.js`:
```javascript
const CONFIG = {
    RENDER_URL: "https://your-api.com",
    BOT_USERNAME: "your_bot",
    // ... other settings
};
```

## 📋 File Organization

### CSS Files by Purpose
- **global.css** - Variables, base styles, animations
- **layout.css** - Navigation, headers, tabs, layout
- **wheel.css** - Lucky Spin wheel modal
- **wallet.css** - Wallet cards and transactions
- **modals.css** - Popups and alerts
- **admin.css** - Admin panels
- **console.css** - Dev console

### JS Files by Feature
- **config.js** - Configuration constants
- **api.js** - Secure API calls, authentication
- **loader.js** - App initialization
- **modals.js** - Alert and confirm dialogs
- **notifications.js** - Inbox and notifications
- **wheel.js** - Lucky Spin wheel game
- **tasks.js** - Task management
- **wallet.js** - Wallet and transfers
- **referrals.js** - Referral system
- **profile.js** - User profile
- **admin.js** - Admin features
- **console.js** - Dev console
- **app.js** - Main app logic and routing

## ✅ Setup Checklist

- [ ] Extract zip file
- [ ] Update `js/config.js` with your settings
- [ ] Add functions to JS files from your original code
- [ ] Add CSS to CSS files from your original code
- [ ] Update image paths (if needed)
- [ ] Test in browser
- [ ] Upload to server

## 🚀 Deployment

```bash
# Copy entire folder to server
scp -r embt-vault-split/ user@server:/path/to/app/

# Keep folder structure intact:
/app/
  └── embt-vault-split/
      ├── index.html
      ├── css/
      ├── js/
      └── components/
```

## 📝 Notes

- **NO CODE CHANGES** - Just reorganized into folders
- **Same functionality** - App works identically
- **Easy to maintain** - Edit one file at a time
- **Keep structure** - Don't move files around

## 🆘 Issues?

1. **Files not loading?**
   - Check file paths in index.html
   - Verify css/ and js/ folders exist

2. **JavaScript errors?**
   - Check browser console (F12)
   - Verify all JS files are present
   - Check that config.js is correct

3. **Styles not applying?**
   - Verify all CSS files are linked
   - Check for CSS file conflicts

See **SETUP_GUIDE.txt** for detailed instructions!

---

**Created:** 2026-06-19
**Version:** 1.0 Split Structure
**Status:** ✅ Ready to Deploy
